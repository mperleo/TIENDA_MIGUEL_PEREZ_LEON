<html>
<body>
<form id="formulario" action="cliente.php" method="get">
<label for="start">Fecha de inicio:</label>
<input type="date" name="fechin">

<label for="start">Fecha final:</label>
<input type="date" id="start" name="fechfin">
<input type="submit" name="act" value="Mostrar resultados">

<fieldset>
        <legend>Seleccione la comunidad:</legend>
		<select name="comunidad">
			<option value="5">Aragón</option>
			<option value="4">Andalucía</option>
			<option value="9">Cataluña</option>
			<option value="6">Cantabria</option>
			<option value="10">País Vasco</option>
			<option value="11">Principado de Asturias</option>
			<option value="8744">Comunidad de Ceuta</option>
			<option value="8745">Comunidad de Melilla</option>
			<option value="8">Castilla y León</option>
			<option value="13">Comunidad de Madrid</option>
			<option value="7">Castilla la Mancha</option>
			<option value="14">Comunidad de Navarra</option>
			<option value="15">Comunidad Valenciana</option>
			<option value="16">Extremadura</option>
			<option value="17">Galicia</option>
			<option value="8743">Islas Baleares</option>
			<option value="8742">Islas Canarias</option>
			<option value="20">La Rioja</option>
			<option value="21">Region de Murcia</option>
		</select>
</fieldset>


</form>

<?php
if(isset($_GET["act"]))
{
		$ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, "https://apidatos.ree.es/es/datos/demanda/demanda-maxima-horaria?geo_limit=ccaa&geo_id=".$_GET["comunidad"]."&start_date=".$_GET["fechin"]."T00:00&end_date=".$_GET["fechfin"]."T22:00&time_trunc=month");

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $response = curl_exec($ch);
		$datos1=json_decode($response, true);
		
		curl_setopt($ch, CURLOPT_URL, "https://apidatos.ree.es/es/datos/demanda/demanda-maxima-diaria?geo_limit=ccaa&geo_id=".$_GET["comunidad"]."&start_date=".$_GET["fechin"]."T00:00&end_date=".$_GET["fechfin"]."T22:00&time_trunc=month");
		$response = curl_exec($ch);
		$datos2=json_decode($response, true);
        curl_close($ch);
		
		//Maxima electrica diaria
		echo $datos2["included"][0]["attributes"]["title"].": ".$datos2["included"][0]["attributes"]["values"][0]["value"]."<br />";
		echo "Ultima actualización: ".$datos2["included"][0]["attributes"]["last-update"]."<br />";
		
		//Maxima horaria
		echo $datos1["included"][0]["attributes"]["title"].": ".$datos1["included"][0]["attributes"]["values"][0]["value"]."<br />";
		echo "Ultima actualización: ".$datos1["included"][0]["attributes"]["last-update"]."<br />";

}
?>
</body>
</html>