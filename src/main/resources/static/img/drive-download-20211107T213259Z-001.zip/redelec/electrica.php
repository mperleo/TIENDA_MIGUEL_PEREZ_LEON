<html>
<body>
<form id="formulario" action="electrica.php" method="get">
<label for="start">Fecha de inicio:</label>
<input type="date" name="fechin">

<label for="start">Fecha final:</label>
<input type="date" id="start" name="fechfin">

<fieldset>
        <legend>Elija la comunidad (NOTA: No funciona la API no filtra las comunidades):</legend>
		<select name="comunidad">
			<option value="8">Castilla y leon</option>
			<option value="7">Castilla la Mancha</option>
			<option value="13">Comunidad de Madrid</option>
		</select>
</fieldset>
<input type="submit" name="act" value="Realizar operación">

</form>

<?php
if(isset($_GET["act"]))
{
		$ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, "https://apidatos.ree.es/es/datos/demanda/demanda-maxima-horaria?start_date=".$_GET["fechin"]."T00:00&end_date=".$_GET["fechfin"]."T22:00&time_trunc=month");

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $output = curl_exec($ch);
		$datos1=json_decode($output, true);
		//var_dump($output);
        // close curl resource to free up system resources
		
		curl_setopt($ch, CURLOPT_URL, "https://apidatos.ree.es/es/datos/demanda/demanda-maxima-diaria?start_date=".$_GET["fechin"]."T00:00&end_date=".$_GET["fechfin"]."T22:00&time_trunc=month");
		$output = curl_exec($ch);
		$datos2=json_decode($output, true);
        curl_close($ch);      
		
		//$datos=json_decode($output, true);
		//var_dump($datos1);
		//var_dump($datos2);
		/*foreach ($datos1 as $clave => $valor) {
			echo $clave;
			echo " 1 ";
		}
		
		foreach ($datos2 as $clave => $valor) {
			echo $clave;
			echo " 2 ";
		}*/
		
		//echo "Maxima electrica diaria.\n";
		echo $datos2["included"][0]["attributes"]["title"]."<br />";
		foreach($datos2["included"][0]["attributes"]["values"] as $resultado){
			echo "Valor: ".$resultado["value"]."<br />";
			echo "Valor: ".$resultado["datetime"]."<br />";
		}
		echo "Ultima actualización: ".$datos2["included"][0]["attributes"]["last-update"]."<br />";
		//echo "Maxima horaria.\n";
		echo $datos1["included"][0]["attributes"]["title"]."<br />";
		foreach($datos1["included"][0]["attributes"]["values"] as $resultado){
			echo "Valor: ".$resultado["value"]."<br />";
			echo "Valor: ".$resultado["datetime"]."<br />";
		}
		echo "Ultima actualización: ".$datos1["included"][0]["attributes"]["last-update"]."<br />";

}
?>
</body>
</html>